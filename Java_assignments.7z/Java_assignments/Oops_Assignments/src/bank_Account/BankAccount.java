package bank_Account;

public abstract class BankAccount {
	
	abstract void totalcash(int cash) ;
	
}
